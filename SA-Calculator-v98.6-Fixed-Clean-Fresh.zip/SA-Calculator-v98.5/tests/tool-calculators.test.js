'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const open = source.indexOf('{', start); let depth = 0;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}
function makeElement(id, values, outputs) {
  const classes = new Set();
  return {
    id, value: values[id] == null ? '' : String(values[id]), textContent: '',
    style: {}, checked: Boolean(values[id]),
    classList: { add: name => classes.add(name), remove: name => classes.delete(name), contains: name => classes.has(name) },
    querySelector: selector => selector === '.input-text' ? { textContent: String(values[id] ?? '') } : null,
    setAttribute() {}, getAttribute() { return null; },
    replaceChildren() {}, appendChild() {},
    _classes: classes
  };
}

test('financial and utility calculators return expected values for representative cases', () => {
  const values = {
    'disc-tax': 10, 'disc-orig': 100, 'disc-pct': 20,
    'pct-init': 200, 'pct-final': 250, 'pct-x': 20, 'pct-y': 300,
    'tax-rate': 10, 'tax-orig': 100, 'tax-mode': 'exclusive',
    'bmi-height': 180, 'bmi-weight': 80, 'bmi-age': 30, 'bmi-gender': 'male',
    'fc-dist': 100, 'fc-eff': 10, 'fc-price': 100,
    'fe-before': 20, 'fe-after': 10, 'fe-added': 30, 'fe-dist': 400,
    'sav-p': 1000, 'sav-r': 5, 'sav-m': 2, 'sav-tax': 10, 'sav-frequency': 'simple',
    'tip-bill': 110, 'tip-pct': 10, 'tip-people': 2, 'tip-tax': 10, 'tip-exclude-tax': true,
    'up-p-a': 10, 'up-q-a': 1, 'up-p-b': 20, 'up-q-b': 4,
    'up-p-c': '', 'up-q-c': '', 'up-p-d': '', 'up-q-d': ''
  };
  const outputs = {};
  const elements = new Map();
  const get = id => { if (!elements.has(id)) elements.set(id, makeElement(id, values, outputs)); return elements.get(id); };
  const rows = ['A','B','C','D'].map(key => get(`up-row-${key}`));
  const document = {
    getElementById: id => get(id),
    querySelector: selector => selector === '#bmi-gender' ? get('bmi-gender') : null,
    querySelectorAll: selector => selector === '.unit-price-grid' ? rows : []
  };
  const context = {
    document, Number, Math, Intl,
    readModuleNumber: id => values[id] === '' || values[id] == null ? NaN : Number(values[id]),
    setElementText: (id, value) => { outputs[id] = String(value); get(id).textContent = String(value); },
    formatResultNumber: value => String(Math.round(Number(value) * 100) / 100),
    STATE: { precision: 'auto', thousandsSep: 'comma' }
  };
  const names = ['calcDiscount','calcPercent','calcSalesTax','calcBodyMetrics','calcFuelCost','calcFuelEfficiency','calcSavings','calcTip','calcUnitPrice'];
  vm.runInNewContext(`${names.map(extract).join('\n')};${names.map(n=>`globalThis.${n}=${n};`).join('')}`, context);
  names.forEach(name => context[name]());
  assert.equal(outputs['disc-saved'], '$ 20');
  assert.equal(outputs['disc-final'], '$ 88');
  assert.equal(outputs['pct-change-res'], '+25%');
  assert.equal(outputs['pct-xy-res'], '60');
  assert.equal(outputs['tax-amt'], '$ 10');
  assert.equal(outputs['tax-total'], '$ 110');
  assert.ok(Math.abs(Number(outputs['bmi-val']) - 24.69) < 0.001);
  assert.equal(outputs['bmr-val'], '1780 kcal');
  assert.equal(outputs['fc-fuel-res'], '10 L');
  assert.equal(outputs['fc-cost-res'], '$ 1000');
  assert.equal(outputs['fe-consumed-res'], '40 L');
  assert.equal(outputs['fe-kml-res'], '10 km/L');
  assert.equal(outputs['fe-l100-res'], '10 L/100km');
  assert.equal(outputs['fe-mpg-res'], '23.52 mpg');
  assert.equal(outputs['sav-int-res'], '$ 90');
  assert.equal(outputs['sav-bal-res'], '$ 1090');
  assert.equal(outputs['tip-amt-res'], '$ 10');
  assert.equal(outputs['tip-tot-res'], '$ 120');
  assert.equal(outputs['tip-per-res'], '$ 60');
  assert.equal(outputs['up-u-a'], '10');
  assert.equal(outputs['up-u-b'], '5');
  assert.match(outputs['up-best-banner'], /Item B/);
});

test('loan amortization produces a bounded schedule and pays down to zero', () => {
  const values = { 'loan-p': 1000, 'loan-r': 12, 'loan-m': 12, 'loan-grace': 0, 'loan-method': 'total' };
  const outputs = {};
  const tbody = { rows: [], replaceChildren() { this.rows = []; }, appendChild(fragment) { this.rows = fragment.children; } };
  const fragment = () => ({ children: [], appendChild(node) { this.children.push(node); } });
  const node = () => ({ children: [], appendChild(child) { this.children.push(child); } });
  const elements = new Map();
  const get = id => { if (!elements.has(id)) elements.set(id, { value: values[id] == null ? '' : String(values[id]), textContent: '', style: {}, className: '' }); return elements.get(id); };
  const document = {
    getElementById: id => get(id),
    querySelector: selector => selector === '#loan-amort tbody' ? tbody : null,
    createDocumentFragment: fragment,
    createElement: node
  };
  const context = { document, Number, Math, setElementText: (id, value) => { outputs[id] = String(value); get(id).textContent = String(value); }, readModuleNumber: id => Number(values[id]), formatResultNumber: value => String(Number(value).toFixed(2)) };
  vm.runInNewContext(`${extract('calcLoan')};globalThis.calcLoan=calcLoan;`, context);
  context.calcLoan();
  assert.equal(tbody.rows.length, 12);
  assert.match(outputs['loan-monthly'], /^\$ 88\.85$/);
  assert.ok(Number(outputs['loan-interest'].replace(/[^0-9.]/g,'')) > 0);
  assert.equal(tbody.rows.at(-1).children.at(-1).textContent, '0.00');

  // Zero-interest loan with two interest-only grace months and equal-principal
  // repayment: the ten repayment months must pay exactly 100 each.
  values['loan-r'] = 0;
  values['loan-grace'] = 2;
  values['loan-method'] = 'principal';
  context.calcLoan();
  assert.equal(tbody.rows.length, 12);
  assert.equal(tbody.rows[0].children[0].textContent, '1');
  assert.equal(tbody.rows[0].children[1].textContent, '0.00');
  assert.equal(tbody.rows[2].children[1].textContent, '100.00');
  assert.equal(outputs['loan-interest'], '$ 0.00');
  assert.equal(outputs['loan-total'], '$ 1000.00');
  assert.match(get('loan-monthly-label').textContent, /Monthly payment after interest-only period/);
});

test('date-event recurrence uses UTC calendar arithmetic and Feb 29 fallback', () => {
  const start = source.indexOf('function dateEventDays(');
  const open = source.indexOf('{', start); let depth = 0, end = -1;
  for (let i = open; i < source.length; i++) { if (source[i] === '{') depth++; else if (source[i] === '}' && --depth === 0) { end = i + 1; break; } }
  const context = { Date, Math };
  vm.runInNewContext(`${source.slice(start, end)};globalThis.days=dateEventDays;`, context);
  assert.equal(context.days({ date: '2000-02-29', repeat: false }, new Date('2025-03-01T12:00:00Z')), -9132);
  assert.equal(context.days({ date: '2000-02-29', repeat: true }, new Date('2025-03-01T12:00:00Z')), 364);
});

test('unit, date, hexadecimal and world-time helpers cover conversion and boundary cases', () => {
  const UNIT_DATA = {
    length: { units: { 'Meter (m)': 1, 'Centimeter (cm)': 0.01 } },
    temperature: { units: { 'Celsius (°C)': 1, 'Fahrenheit (°F)': 1, 'Kelvin (K)': 1 } },
    fuel: { units: { 'Kilometers per liter (km/L)': 1, 'Liters per 100 km (L/100 km)': 1, 'Miles per US gallon (mpg US)': 1 } }
  };
  const context = { UNIT_DATA, Number, Math, Date, Intl, BigInt, String };
  vm.runInNewContext(`${extract('convertUnitValue')};${extract('validISODate')};${extract('hexCurrentBigInt')};${extract('worldTimeDateTimeValue')};let hexBase=16,hexDigits='FFFFFFFF';globalThis.convert=convertUnitValue;globalThis.valid=validISODate;globalThis.hex=hexCurrentBigInt;globalThis.world=worldTimeDateTimeValue;`, context);
  assert.equal(context.convert('length', 2, 'Meter (m)', 'Centimeter (cm)'), 200);
  assert.equal(context.convert('temperature', 32, 'Fahrenheit (°F)', 'Celsius (°C)'), 0);
  assert.equal(context.convert('temperature', -273.15, 'Celsius (°C)', 'Kelvin (K)'), 0);
  assert.ok(Number.isNaN(context.convert('temperature', -1, 'Kelvin (K)', 'Celsius (°C)')));
  assert.ok(Number.isNaN(context.convert('temperature', -300, 'Celsius (°C)', 'Kelvin (K)')));
  assert.equal(context.convert('fuel', 10, 'Kilometers per liter (km/L)', 'Liters per 100 km (L/100 km)'), 10);
  assert.equal(context.valid('2024-02-29'), true);
  assert.equal(context.valid('2025-02-29'), false);
  assert.equal(context.hex().toString(), '4294967295');
  assert.match(context.world('Asia/Kolkata', new Date('2026-11-13T00:00:00Z')), /^2026-11-13T/);
});

test('weighted GPA ignores empty/zero-credit rows and uses credit-weighted grade points', () => {
  const outputs = {};
  const rows = [
    { querySelector: selector => selector === '.gpa-credits' ? { value: '3' } : selector === '.gpa-grade' ? { value: '4' } : null },
    { querySelector: selector => selector === '.gpa-credits' ? { value: '1' } : selector === '.gpa-grade' ? { value: '2' } : null },
    { querySelector: selector => selector === '.gpa-credits' ? { value: '0' } : selector === '.gpa-grade' ? { value: '4' } : null },
    { querySelector: selector => selector === '.gpa-credits' ? { value: '' } : selector === '.gpa-grade' ? { value: '3' } : null }
  ];
  const context = {
    document: { querySelectorAll: selector => selector === '#gpa-rows .gpa-course-row' ? rows : [] },
    Number, Math,
    formatResultNumber: value => Number(value).toFixed(2),
    setElementText: (id, value) => { outputs[id] = String(value); }
  };
  vm.runInNewContext(`${extract('calcGpa')};globalThis.run=calcGpa;`, context);
  context.run();
  assert.equal(outputs['gpa-credits-res'], '4.00');
  assert.equal(outputs['gpa-val-res'], '3.50');
});
